export class HeroeModel {

    constructor(public id:string, public name: string,public picture: string,public health: number,public damage: number,public userId:string){

    }
  
}

