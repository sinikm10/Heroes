export const environment = {
  production: true,
  firebaseAPIkey:'AIzaSyAi6fV3O45BGo9Qa-15c_ah8mMOVi_frLI'
};
